import 'package:flutter/material.dart';

class MyContacts extends StatelessWidget {
  const MyContacts({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
