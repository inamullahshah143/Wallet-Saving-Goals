package com.zence.wallet_saving_goals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
